#ifndef TIME_H
#define TIME_H

#include "Platform.h"

uint64_t	Now();
uint64_t	NowMicro();
void		USleep(unsigned long msec);

#endif
