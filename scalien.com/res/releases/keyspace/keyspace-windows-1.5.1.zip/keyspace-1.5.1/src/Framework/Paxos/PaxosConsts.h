#ifndef PAXOS_CONSTS
#define PAXOS_CONSTS

#define PAXOS_SIZE (500*KB)
#define RLOG_SIZE (PAXOS_SIZE + 10*KB)


#endif
