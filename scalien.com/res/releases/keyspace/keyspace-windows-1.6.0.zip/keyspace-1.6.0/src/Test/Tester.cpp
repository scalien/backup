#include "Test.h"

int bdbtest();

TEST_MAIN(bdbtest);
