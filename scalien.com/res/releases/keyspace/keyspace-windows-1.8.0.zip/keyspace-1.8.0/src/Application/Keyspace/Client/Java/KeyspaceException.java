package com.scalien.keyspace;

public class KeyspaceException extends java.lang.Exception {
	public KeyspaceException(String msg) {
		super(msg);
	}
}
